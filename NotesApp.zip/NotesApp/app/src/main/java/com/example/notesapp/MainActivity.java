package com.example.notesapp;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    EditText titleInput, contentInput, timeInput;
    Button saveBtn;
    List<Note> notes = new ArrayList<>();
    SharedPreferences prefs;
    Gson gson = new Gson();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        titleInput = findViewById(R.id.noteTitle);
        contentInput = findViewById(R.id.noteContent);
        timeInput = findViewById(R.id.noteTime);
        saveBtn = findViewById(R.id.saveBtn);

        prefs = getSharedPreferences("notes_db", MODE_PRIVATE);
        loadNotes();

        saveBtn.setOnClickListener(v -> saveNote());
    }

    private void saveNote() {
        String title = titleInput.getText().toString();
        String content = contentInput.getText().toString();
        int minutes = Integer.parseInt(timeInput.getText().toString());

        long timeInMillis = Calendar.getInstance().getTimeInMillis() + (minutes * 60000);

        Note note = new Note(title, content, timeInMillis);
        notes.add(note);
        saveNotes();

        setReminder(note);

        titleInput.setText("");
        contentInput.setText("");
        timeInput.setText("");
    }

    private void setReminder(Note note) {
        Intent intent = new Intent(this, AlarmReceiver.class);
        intent.putExtra("title", note.getTitle());
        intent.putExtra("content", note.getContent());

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this,
                (int) System.currentTimeMillis(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                note.getTime(),
                pendingIntent
        );
    }

    private void saveNotes() {
        String json = gson.toJson(notes);
        prefs.edit().putString("notes", json).apply();
    }

    private void loadNotes() {
        String json = prefs.getString("notes", null);
        if (json != null) {
            Type type = new TypeToken<List<Note>>(){}.getType();
            notes = gson.fromJson(json, type);
        }
    }
}
